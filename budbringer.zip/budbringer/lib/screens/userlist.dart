import 'dart:convert';
import 'dart:io';

import 'package:budbringer/services/authentication.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import '../services/databaseservice.dart';
// import '../models/user_data.dart';
import '../models/user_model.dart';
import '../utilities/constants.dart';
import '../widgets/messenger_tile_view.dart';
// import 'package:provider/provider.dart';
import '../utilities/color_const.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:fluttertoast/fluttertoast.dart';

class UserList extends StatefulWidget {
  final String currentUserId;

  UserList({Key key, @required this.currentUserId}) : super(key: key);

  @override
  State createState() => UserListState(currentUserId: currentUserId);
}

class UserListState extends State<UserList> {
  UserListState({Key key, @required this.currentUserId});
  List<User> _people;
  final String currentUserId;
  final FirebaseMessaging firebaseMessaging = new FirebaseMessaging();
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      new FlutterLocalNotificationsPlugin();

  bool isLoading = false;
  List<Choice> choices = const <Choice>[
    const Choice(title: 'Settings', icon: Icons.settings),
    const Choice(title: 'Log out', icon: Icons.exit_to_app),
  ];

  @override
  void initState() {
    super.initState();
    registerNotification();
    configLocalNotification();
    _setuplist();
  }

  void registerNotification() {
    firebaseMessaging.requestNotificationPermissions();

    firebaseMessaging.configure(onMessage: (Map<String, dynamic> message) {
      print('onMessage: $message');
      showNotification(message['notification']);
      return;
    }, onResume: (Map<String, dynamic> message) {
      print('onResume: $message');
      return;
    }, onLaunch: (Map<String, dynamic> message) {
      print('onLaunch: $message');
      return;
    });

    firebaseMessaging.getToken().then((token) {
      print('token: $token');
      Firestore.instance
          .collection('users')
          .document(currentUserId)
          .updateData({'pushToken': token});
    }).catchError((err) {
      Fluttertoast.showToast(msg: err.message.toString());
    });
  }

  void configLocalNotification() {
    var initializationSettingsAndroid =
        new AndroidInitializationSettings('app_icon');
    var initializationSettingsIOS = new IOSInitializationSettings();
    var initializationSettings = new InitializationSettings(
        initializationSettingsAndroid, initializationSettingsIOS);
    flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  void showNotification(message) async {
    var androidPlatformChannelSpecifics = new AndroidNotificationDetails(
      Platform.isAndroid
          ? 'com.dfa.flutterchatdemo'
          : 'com.example.login_feeds_fire',
      'Amor',
      'Chat',
      playSound: true,
      enableVibration: true,
      importance: Importance.Max,
      priority: Priority.High,
    );
    var iOSPlatformChannelSpecifics = new IOSNotificationDetails();
    var platformChannelSpecifics = new NotificationDetails(
        androidPlatformChannelSpecifics, iOSPlatformChannelSpecifics);
    await flutterLocalNotificationsPlugin.show(0, message['title'].toString(),
        message['body'].toString(), platformChannelSpecifics,
        payload: json.encode(message));
  }

  _setuplist() async {
    QuerySnapshot peoplesnap = await followersRef
        .document(currentUserId)
        .collection('userFollowers')
        .getDocuments();
    List<User> people =
        peoplesnap.documents.map((doc) => User.fromDoc(doc)).toList();
    setState(() {
      _people = people;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text('Chats',
            style: TextStyle(color: primaryColor, fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: <Widget>[
          RaisedButton(
            child: Text('Log Out'),
            onPressed: () => Auth.logout(context),
          ),
        ],
      ),
      body: Stack(
        children: <Widget>[
          // List
          Container(
            child: StreamBuilder(
              stream:
                  // followingRef
                  //     .document(Provider.of<UserData>(context).currentUserId)
                  //     .collection('userFollowing')
                  //     .snapshots(),

                  Firestore.instance.collection('users').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(themeColor),
                    ),
                  );
                } else {
                  return _people == null
                      ? Center(child: CircularProgressIndicator())
                      : ListView.builder(
                          itemCount: _people.length,
                          itemBuilder: (BuildContext context, int index) {
                            User person = _people[index];
                            return FutureBuilder(
                              future: DatabaseService.getUserWithId(person.id),
                              builder: (BuildContext context,
                                  AsyncSnapshot snapshot) {
                                if (!snapshot.hasData) {
                                  return SizedBox.shrink();
                                }
                                User personlocal = snapshot.data;
                                return MessengerTiles(
                                  currentUserId: widget.currentUserId,
                                  contact: personlocal,
                                );
                              },
                            );
                          },
                        );
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}

class Choice {
  const Choice({this.title, this.icon});

  final String title;
  final IconData icon;
}
