import 'package:flutter/foundation.dart';

class UserData extends ChangeNotifier {
  
  String currentUserId;
  int unreadmessagecount;

}
