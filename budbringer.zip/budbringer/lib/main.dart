import 'package:budbringer/screens/login.dart';
import 'package:budbringer/screens/userlist.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  final FirebaseAuth auth = FirebaseAuth.instance;
  Widget _getScreenId(){

    return StreamBuilder<FirebaseUser>(
      stream: FirebaseAuth.instance.onAuthStateChanged,
      builder: (BuildContext context, snapshot) {
          if (snapshot.hasData){
            return UserList(currentUserId: snapshot.data.uid);
          }
          else {
            print(snapshot);
            return LoginScreen();
          }
      },
    );
  
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      themeMode: ThemeMode.dark,
      home: _getScreenId(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.user}) : super(key: key);

  final FirebaseUser user;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: RaisedButton(
          child: Text('Log Out'),
          onPressed: () {
            FirebaseAuth.instance.signOut();
            Navigator.pushReplacement(context, MaterialPageRoute(
              builder: (context) => LoginScreen()
            ));
          },
        ),
      ),
    );
  }
}
